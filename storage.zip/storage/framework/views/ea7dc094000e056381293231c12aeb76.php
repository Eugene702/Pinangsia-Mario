<input
    <?php echo e($attributes
            ->merge([
                'id' => $getId(),
                'type' => 'hidden',
                $applyStateBindingModifiers('wire:model') => $getStatePath(),
            ], escape: false)
            ->merge($getExtraAttributes(), escape: false)
            ->class(['fi-fo-hidden'])); ?>

/>
<?php /**PATH D:\FREELANCE\Projects\Demario\house-keeping-management\vendor\filament\forms\src\/../resources/views/components/hidden.blade.php ENDPATH**/ ?>