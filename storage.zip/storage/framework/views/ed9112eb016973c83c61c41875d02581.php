<h2
    <?php echo e($attributes->class(['fi-modal-heading text-base font-semibold leading-6 text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH D:\FREELANCE\Projects\Demario\house-keeping-management\vendor\filament\support\src\/../resources/views/components/modal/heading.blade.php ENDPATH**/ ?>