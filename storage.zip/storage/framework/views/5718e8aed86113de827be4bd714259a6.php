<!DOCTYPE html>
<html>

<head>
    <title><?php echo e($title); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .header h1 {
            margin-bottom: 5px;
        }

        .header p {
            margin-top: 0;
            color: #666;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .footer {
            margin-top: 20px;
            text-align: right;
            font-size: 10px;
            color: #666;
        }
    </style>
</head>

<body>
    <div class="header">
        <h1><?php echo e($title); ?></h1>
        <p>Dicetak pada: <?php echo e(now()->format('d/m/Y H:i')); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Peminjam</th>
                <th>Tgl Pinjam</th>
                <th>Tgl Kembali</th>
                <th>Status</th>
                <th>Catatan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $borrowings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $borrowing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($borrowing->inventory->name); ?></td>
                    <td><?php echo e($borrowing->borrowed_quantity); ?></td>
                    <td><?php echo e($borrowing->user->name); ?></td>
                    <td><?php echo e($borrowing->borrowed_at->format('d/m/Y H:i')); ?></td>
                    <td><?php echo e($borrowing->returned_at?->format('d/m/Y H:i') ?? '-'); ?></td>
                    <td>
                        <?php if($borrowing->status == 'borrowed'): ?>
                            <span style="color: orange;">Dipinjam</span>
                        <?php elseif($borrowing->status == 'returned'): ?>
                            <span style="color: green;">Dikembalikan</span>
                        <?php else: ?>
                            <span style="color: red;"><?php echo e(ucfirst($borrowing->status)); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($borrowing->notes); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="footer">
        <?php echo e(config('app.name')); ?> - <?php echo e(now()->year); ?>

    </div>
</body>

</html>
<?php /**PATH D:\FREELANCE\Projects\Demario\house-keeping-management\resources\views/borrowing_history_pdf.blade.php ENDPATH**/ ?>