<x-filament-panels::page>

</x-filament-panels::page>
