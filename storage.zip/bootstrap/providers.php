<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\Filament\HousekeepingPanelProvider::class,
    App\Providers\Filament\ManagerPanelProvider::class,
    App\Providers\Filament\ReceptionistPanelProvider::class,
];
