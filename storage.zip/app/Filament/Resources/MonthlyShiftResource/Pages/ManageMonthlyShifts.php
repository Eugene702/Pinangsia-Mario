<?php

namespace App\Filament\Resources\MonthlyShiftResource\Pages;

use App\Filament\Resources\MonthlyShiftResource;
use Filament\Actions;
use Filament\Resources\Pages\ManageRecords;

class ManageMonthlyShifts extends ManageRecords
{
    protected static string $resource = MonthlyShiftResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
